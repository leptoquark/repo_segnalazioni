package it.anac.segnalazioni.backoffice.rest;

import java.io.IOException;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.opencsv.exceptions.CsvValidationException;

import it.anac.segnalazioni.backoffice.db.MongoSubmission;
import it.anac.segnalazioni.backoffice.web.model.Assegnazione;
import it.anac.segnalazioni.backoffice.web.util.FirmUsers;

@RestController
@RequestMapping(path="/ws")
public class UIServices {
	
	@Autowired
	private MongoSubmission ms;
	
	@Autowired
	private SchedulerService ss;

	@GetMapping("/aggiorna-segnalazione")
	public String aggiornaSegnalazione(String idSubmission, String ufficio, String utente, String protocolloChiusura, String motivazione, String priorita) throws IOException
	{
		return (ms.setChiusura(idSubmission,ufficio,utente,protocolloChiusura, motivazione, priorita));
	}
	
	@GetMapping("/assegnatari-protocollo")
	public List<String> assegnatariFromProtocollo(int anno, int protocollo, String ufficio) throws IOException, CsvValidationException
	{
		List<String> ret = new LinkedList<String>();
		
		List<Assegnazione> assegnazioni = ss.getAssegnazioni(anno, protocollo);
		
		for(int i=0; i<assegnazioni.size(); i++)
		{
			if (assegnazioni.get(i).getUfficioAssegnatario().contains(ufficio))
				ret.add(FirmUsers.getNomeCognomeFromUsername(assegnazioni.get(i).getUtenteAssegnatario()));
		}
		
		return ret;
	}
}
