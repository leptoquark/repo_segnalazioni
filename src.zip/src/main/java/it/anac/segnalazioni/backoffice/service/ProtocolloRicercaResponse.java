package it.anac.segnalazioni.backoffice.service;

import java.util.List;

import it.anac.segnalazioni.client.protocollo.ProtocolloViewType;

public class ProtocolloRicercaResponse {
	
	private ProtocolloBaseResponse protocolloBaseResponse;
	private List <ProtocolloViewType> protocolli;	

	public ProtocolloBaseResponse getProtocolloBaseResponse() {
		return protocolloBaseResponse;
	}
	public void setProtocolloBaseResponse(ProtocolloBaseResponse protocolloBaseResponse) {
		this.protocolloBaseResponse = protocolloBaseResponse;
	}
	public List<ProtocolloViewType> getProtocolli() {
		return protocolli;
	}
	public void setProtocolli(List<ProtocolloViewType> protocolli) {
		this.protocolli = protocolli;
	}
}