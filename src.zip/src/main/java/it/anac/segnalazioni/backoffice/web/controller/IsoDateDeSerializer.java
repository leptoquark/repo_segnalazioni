package it.anac.segnalazioni.backoffice.web.controller;

import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.ObjectCodec;
import com.fasterxml.jackson.databind.DeserializationContext;
import com.fasterxml.jackson.databind.JsonDeserializer;
import com.fasterxml.jackson.databind.JsonNode;

public class IsoDateDeSerializer extends JsonDeserializer<Date> {
	
	public Date deserialize(JsonParser jsonParser, DeserializationContext deserializationContext)
			throws IOException, JsonProcessingException {
		ObjectCodec oc = jsonParser.getCodec();
		JsonNode node = oc.readTree(jsonParser);
		String dateValue = node.get("$date").asText();
		DateFormat df = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.sssXXX");
		Date date = null;
		try {
			date = df.parse(dateValue);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return date;
	}
}
