package it.anac.segnalazioni.backoffice.web.model;

public class SegnalazioneTableTrasparenza extends SegnalazioneTable {
	
	private String tipo_ente;
	private String tipo_segnalazione;
	private String sezione_trasparenza;
	
	public String getTipo_ente() {
		return tipo_ente;
	}
	public void setTipo_ente(String tipo_ente) {
		this.tipo_ente = tipo_ente;
	}
	public String getTipo_segnalazione() {
		return tipo_segnalazione;
	}
	public void setTipo_segnalazione(String tipo_segnalazione) {
		this.tipo_segnalazione = tipo_segnalazione;
	}
	public String getSezione_trasparenza() {
		return sezione_trasparenza;
	}
	public void setSezione_trasparenza(String sezione_trasparenza) {
		this.sezione_trasparenza = sezione_trasparenza;
	}

}