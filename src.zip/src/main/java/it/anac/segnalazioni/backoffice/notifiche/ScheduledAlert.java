package it.anac.segnalazioni.backoffice.notifiche;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import it.anac.segnalazioni.backoffice.notifiche.model.Notifica;

@Component
public class ScheduledAlert {
	
	@Autowired
	private AlertEngine alertEngine;

	// JOB per lo scodamento ed invio delle notifiche
    @Scheduled(cron="*/10 * * * * *")
    @Scheduled(cron="${backoffice.notifiche.unqueue}")
	public void unqueueAlert() {  
    	alertEngine.scodaNotifiche();
	}

    /* Inviato alle 9.30 del 31/3 di tutti gli anni*/ 
    // backoffice.notifiche.q1=0 30 9 31 3 * *
    @Scheduled(cron="${backoffice.notifiche.q1}")
	public void alertQ1() {     	
    	/* TODO: inserire qui la logica di accodamento */
    	boolean accoda = false;
    	
    	if (accoda)
    	{
    		Notifica notifica = new Notifica();
    		alertEngine.accodaNotifica(notifica);
    	}
	}
    
    /* Inviato alle 9.30 del 30/6 di tutti gli anni*/ 
    // backoffice.notifiche.q2=0 30 9 30 6 * *
    @Scheduled(cron="${backoffice.notifiche.q2}")
	public void alertQ2() {     	
    	/* TODO: inserire qui la logica di accodamento */
    	boolean accoda = false;
    	
    	if (accoda)
    	{
    		Notifica notifica = new Notifica();
    		alertEngine.accodaNotifica(notifica);
    	}
	}
    
    /* Inviato alle 9.30 del 30/9 di tutti gli anni*/ 
    // backoffice.notifiche.q2=0 30 9 30 9 * *
    @Scheduled(cron="${backoffice.notifiche.q3}")
	public void alertQ3() {     	
    	/* TODO: inserire qui la logica di accodamento */
    	boolean accoda = false;
    	
    	if (accoda)
    	{
    		Notifica notifica = new Notifica();
    		alertEngine.accodaNotifica(notifica);
    	}
	}
    
    /* Inviato alle 9.30 del 31/12 di tutti gli anni*/ 
    // backoffice.notifiche.q2=0 30 9 31 12 * *
    @Scheduled(cron="${backoffice.notifiche.q4}")
	public void alertQ4() {     	
    	/* TODO: inserire qui la logica di accodamento */
    	boolean accoda = false;
    	
    	if (accoda)
    	{
    		Notifica notifica = new Notifica();
    		alertEngine.accodaNotifica(notifica);
    	}
	}
    
    @Scheduled(cron="${backoffice.notifiche.event}")
	public void alertEvento() {
    	/* TODO: inserire qui la logica di accodamento */
    	
    	boolean accoda = false;
    	
    	if (accoda)
    	{
    		Notifica notifica = new Notifica();
    		alertEngine.accodaNotifica(notifica);
    	}
	}
}
