package it.anac.segnalazioni.backoffice.web.model;

public class SegnalazioneTableAnticorruzione extends SegnalazioneTable {
	
	private String segnalato;
	private String questione;
	
	public String getSegnalato() {
		return segnalato;
	}
	public void setSegnalato(String segnalato) {
		this.segnalato = segnalato;
	}
	public String getQuestione() {
		return questione;
	}
	public void setQuestione(String questione) {
		this.questione = questione;
	}

}
