package it.anac.segnalazioni.backoffice.db.model;

import java.text.SimpleDateFormat;

/**
 * @author Giancarlo Carbone
 *
 */

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import it.anac.segnalazioni.backoffice.web.controller.IsoDateDeSerializer;
public class Segnalazione {
	
	// Persona fisica che effettua la segnalazione
	private Segnalante segnalante;
	
	// Oggetto della segnalazione
	private String oggetto;
	
	// Data della segnalazione
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date data;
	
	// Area della segnalazione
	private String area;
	
	// Documenti allegati
	private List<Allegato> allegati;
	
	// Altri soggetti istituzionali
	private List<String> altriSoggetti;
	
	// Esclusione dalla pubblicazione
	private String esclusione;
	
	// Esistenza di contenzioso sul medesimo oggetto
	private boolean contenzioso = false;
	
	// Contenziosi
	private List<Contenzioso> contenziosi;
	
	public Segnalazione() {}
	
	public Segnalazione(Segnalante segnalante, Date data, String area) {
		super();
		this.segnalante = segnalante;
		this.data = data;
		this.area = area;
		this.allegati = new ArrayList<Allegato>();
		this.altriSoggetti = new ArrayList<String>();
		this.contenziosi = new ArrayList<Contenzioso>(0);
	}

	public Segnalante getSegnalante() {
		return segnalante;
	}
	public void setSegnalante(Segnalante segnalante) {
		this.segnalante = segnalante;
	}
	public String getOggetto() {
		return oggetto;
	}
	public void setOggetto(String oggetto) {
		this.oggetto = oggetto;
	}
	public Date getData() {
		return data;
	}
	
	public void setData(Date data) {
		this.data = data;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getEsclusione() {
		return esclusione;
	}
	public void setEsclusione(String esclusione) {
		this.esclusione = esclusione;
	}
	
	public void addAllegato(Allegato allegato) {
		this.allegati.add(allegato);
	}
	public void addAltroSoggetto(String altroSoggetto) {
		this.altriSoggetti.add(altroSoggetto);
	}

	public List<Allegato> getAllegati() {
		return allegati;
	}
	public void setAllegati(List<Allegato> allegati) {
		this.allegati = allegati;
	}
	public List<String> getAltriSoggetti() {
		return altriSoggetti;
	}
	public void setAltriSoggetti(List<String> altriSoggetti) {
		this.altriSoggetti = altriSoggetti;
	}
	
	public boolean isContenzioso() {
		return contenzioso;
	}

	public void setContenzioso(boolean contenzioso) {
		this.contenzioso = contenzioso;
	}

	public List<Contenzioso> getContenziosi() {
		return contenziosi;
	}

	public void setContenziosi(List<Contenzioso> contenziosi) {
		this.contenziosi = contenziosi;
	}
	
	public void addContenzioso(Contenzioso c) {
		this.contenziosi.add(c);
	}


	@Override
	public String toString() {
		 return  "Segnalazione{" +
	             "segnalante='" + segnalante.toString() + "'" +
				 "oggetto='" + oggetto + "'" +
	             "data='" + data + "'" + 
				 "area='" + area + "'" +
				 "} " + super.toString();
	}
}
