package it.anac.segnalazioni.backoffice.web.model;

public class SegnalazioneTableAppalto extends SegnalazioneTable {
	
	private String stazioneAppaltante;
	private String cig;
	private String oe;
	private String ambito;
	private String importo;
	private String proceduraAffidamento;
	private String fase;
	private String rup;
	private String oggettoContratto;
	
	public String getStazioneAppaltante() {
		return stazioneAppaltante;
	}
	public void setStazioneAppaltante(String stazioneAppaltante) {
		this.stazioneAppaltante = stazioneAppaltante;
	}
	public String getCig() {
		return cig;
	}
	public void setCig(String cig) {
		this.cig = cig;
	}
	public String getOe() {
		return oe;
	}
	public void setOe(String oe) {
		this.oe = oe;
	}
	public String getAmbito() {
		return ambito;
	}
	public void setAmbito(String ambito) {
		this.ambito = ambito;
	}
	public String getImporto() {
		return importo;
	}
	public void setImporto(String importo) {
		this.importo = importo;
	}
	public String getProceduraAffidamento() {
		return proceduraAffidamento;
	}
	public void setProceduraAffidamento(String proceduraAffidamento) {
		this.proceduraAffidamento = proceduraAffidamento;
	}
	public String getFase() {
		return fase;
	}
	public void setFase(String fase) {
		this.fase = fase;
	}
	public String getRup() {
		return rup;
	}
	public void setRup(String rup) {
		this.rup = rup;
	}
	public String getOggettoContratto() {
		return oggettoContratto;
	}
	public void setOggettoContratto(String oggettoContratto) {
		this.oggettoContratto = oggettoContratto;
	}
}