package it.anac.segnalazioni.backoffice.db.model;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.List;

import it.anac.segnalazioni.backoffice.web.util.Mapper;

public class Ufficio {
	
	private String denominazione;
	private String utenteModifica;
	
	private String stato;
	private String motivazione;
	
	private String priorita;
	
	public String getPriorita() {
		return priorita;
	}
	public void setPriorita(String priorita) {
		this.priorita = priorita;
	}
	private Date dataChiusuraDate = new Date();
	
	private String protocolloChiusura;
	
	private List<Assegnatario> assegnatari;
	
	public String getMotivazione() {
		return motivazione;
	}
	public void setMotivazione(String motivazione) {
		this.motivazione = motivazione;
	}
	public List<Assegnatario> getAssegnatari() {
		return assegnatari;
	}
	public void setAssegnatari(List<Assegnatario> assegnatari) {
		this.assegnatari = assegnatari;
	}
	public Date getDataChiusuraDate() {
		return dataChiusuraDate;
	}
	public void setDataChiusuraDate(Date dataChiusuraDate) {
		this.dataChiusuraDate = dataChiusuraDate;
	}

	public String getStato() {
		return stato.toUpperCase();
	}
	public void setStato(String stato) {
		this.stato = stato;
	}
	public String getDenominazione() {
		
		return denominazione;
	}
	public void setDenominazione(String denominazione) {
		this.denominazione = Mapper.getAcronimo(denominazione);
	}
	public String getUtenteModifica() {
		return utenteModifica;
	}
	public void setUtenteModifica(String utenteModifica) {
		this.utenteModifica = utenteModifica;
	}
	public String getDataChiusura() {
		if (dataChiusuraDate==null) return null;
		SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
		return sdf.format(dataChiusuraDate);
	}
	public void setDataChiusura(String dataChiusura) {
		
		if (dataChiusura!=null && !dataChiusura.trim().equals(""))
		{
			LocalDate dataChiusura_localDate = LocalDate.parse(dataChiusura, DateTimeFormatter.ISO_DATE_TIME);
			Date dataChiusura_aux = Date.from(dataChiusura_localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
			setDataChiusuraDate(dataChiusura_aux);
		}
	}
	public String getProtocolloChiusura() {
		return protocolloChiusura;
	}
	public void setProtocolloChiusura(String protocolloChiusura) {
		this.protocolloChiusura = protocolloChiusura;
	}
	
	
}