package it.anac.segnalazioni.backoffice.rest;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.jdbc.core.JdbcTemplate;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.anac.segnalazioni.backoffice.web.model.Assegnazione;

@RestController
@RequestMapping(path="/ws")
public class SchedulerService {
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Value("${protocollo.sql.ufficiAssegnatari}")
    private String sql_assegnatari;
	
	@Value("${protocollo.sql.assegnazioni}")
    private String sql_assegnazioni;
	
	@SuppressWarnings("deprecation")
	public List<String> getUfficiAssegnatari(int anno, int protocollo) throws IOException
	{
        Integer[] params = new Integer[2];
        params[0] = Integer.valueOf(protocollo);
        params[1] = Integer.valueOf(anno);
        List<String> uffici = jdbcTemplate.queryForList(sql_assegnatari,params,String.class);
		return uffici;
	}
	
	@SuppressWarnings("deprecation")
	@GetMapping("/assegnazioni")
	public List<Assegnazione> getAssegnazioni(int anno, int protocollo) throws IOException
	{
        Integer[] params = new Integer[2];
        params[0] = Integer.valueOf(anno);
        params[1] = Integer.valueOf(protocollo);
        List<Map<String, Object>> rows = jdbcTemplate.queryForList(sql_assegnazioni,params);
        
        List<Assegnazione> assegnazioni = new ArrayList<>();
        
        for (Map row : rows) {
            Assegnazione obj = new Assegnazione();
            
            obj.setAnno((Integer) row.get("Anno"));
            obj.setNrProtocollo((Integer) row.get("NrProtocollo"));
            obj.setDataProtocollo((String) row.get("DataProtocollo"));
            obj.setDataAssegnazione((String) row.get("DataAssegnazione"));
            obj.setUfficioAssegnante((String) row.get("UfficioAssegnante"));
            obj.setUtenteAssegnante((String) row.get("UtenteAssegnante"));
            obj.setUfficioAssegnatario((String) row.get("UfficioAssegnante"));
            obj.setUtenteAssegnatario((String) row.get("UtenteAssegnatario"));
            obj.setStatoAssegnazione((String) row.get("StatoAssegnazione"));
            assegnazioni.add(obj);
        }
        
		return assegnazioni;
	}
}
