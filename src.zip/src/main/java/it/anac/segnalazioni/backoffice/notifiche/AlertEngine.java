package it.anac.segnalazioni.backoffice.notifiche;

import java.util.Date;
import java.util.List;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import it.anac.segnalazioni.backoffice.notifiche.mail.MailSendHelper;
import it.anac.segnalazioni.backoffice.notifiche.model.Destinatario;
import it.anac.segnalazioni.backoffice.notifiche.model.Notifica;

@Component
public class AlertEngine {
	@Autowired
	private MongoTemplate mongoTemplate;
	
	@Autowired
	private MailSendHelper msh;
	
	public void accodaNotifica(Notifica notifica)
	{
		mongoTemplate.insert(notifica,"notifiche");	
	}
	
	public List<Notifica> scodaNotifiche()
	{
    	Query query = new Query();
    	
    	query.addCriteria(Criteria.where("inviata").is(false).and("data").lte(new Date()));
    	List<Notifica> notifiche = mongoTemplate.find(query,Notifica.class);    
    	
    	for(int i=0; i<notifiche.size(); i++)
			try {
				System.out.println("NOTIFICA "+i);
				notifica(notifiche.get(i));
				
				Notifica aux = notifiche.get(i);
				aux.setInviata(true);
				notifiche.set(i,aux);
				
			} catch (MessagingException e) {				
				e.printStackTrace();
				return null;
			}
    	
    	Update update = new Update();
    	update.set("inviata", true);
    	mongoTemplate.updateMulti(query, update, Notifica.class);
    	    	
    	return notifiche;
	}
	
	private void notifica(Notifica notifica) throws MessagingException
	{
		List<Destinatario> destinatari = notifica.getDestinatari();
		String[]tos = new String[destinatari.size()];
		
		for(int i=0; i<destinatari.size(); i++)
			tos[i]=destinatari.get(i).getEmail();
		
	
		msh.sendMessage(tos,
						notifica.getMessaggio().getOggetto(),
						notifica.getMessaggio().getMessaggio());
	}

}
