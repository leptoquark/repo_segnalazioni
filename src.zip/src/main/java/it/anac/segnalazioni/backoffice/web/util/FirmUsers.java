package it.anac.segnalazioni.backoffice.web.util;

import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.util.StringTokenizer;

import com.opencsv.CSVParser;
import com.opencsv.CSVParserBuilder;
import com.opencsv.CSVReader;
import com.opencsv.CSVReaderBuilder;
import com.opencsv.exceptions.CsvValidationException;



public class FirmUsers {
	
	private static final String ORGANIZZAZIONE = "elencoDipendenti.csv";

	public static String getUfficioFromUsername(String username) throws CsvValidationException, IOException
	{
		String ret = "";
		
		FileReader reader;
		CSVParser parser;
		CSVReader csvReader;
		

			reader = new FileReader(new File(ORGANIZZAZIONE));
			
			parser = new CSVParserBuilder()
				    .withSeparator(';')
				    .withIgnoreQuotations(true)
				    .build();

		    csvReader = new CSVReaderBuilder(reader)
				    .withSkipLines(0)
				    .withCSVParser(parser)
				    .build();

		    String[] line;
		    
		    while ((line = csvReader.readNext()) != null)
		    {
		    	if (line[3].toLowerCase().contains(username.toLowerCase()))
		    		ret = line[7];
		    }
		    
			csvReader.close();
			reader.close();
		    
		return ret;
	}
	
	public static String getRuoloFromUsername(String username) throws CsvValidationException, IOException
	{
		String ret = "";
		
		FileReader reader;
		CSVParser parser;
		CSVReader csvReader;
		

			reader = new FileReader(new File(ORGANIZZAZIONE));
			
			parser = new CSVParserBuilder()
				    .withSeparator(';')
				    .withIgnoreQuotations(true)
				    .build();

		    csvReader = new CSVReaderBuilder(reader)
				    .withSkipLines(0)
				    .withCSVParser(parser)
				    .build();

		    String[] line;
		    
		    while ((line = csvReader.readNext()) != null)
		    {
		    	if (line[3].toLowerCase().contains(username.toLowerCase()))
		    		ret = line[4];
		    }
		    
			csvReader.close();
			reader.close();
		    
		return ret;
	}
	
	public static String getNomeCognomeFromUsername(String username) throws CsvValidationException, IOException
	{
		String ret = "";
		
		FileReader reader;
		CSVParser parser;
		CSVReader csvReader;
		

			reader = new FileReader(new File(ORGANIZZAZIONE));
			
			parser = new CSVParserBuilder()
				    .withSeparator(';')
				    .withIgnoreQuotations(true)
				    .build();

		    csvReader = new CSVReaderBuilder(reader)
				    .withSkipLines(0)
				    .withCSVParser(parser)
				    .build();

		    String[] line;
		    
		    while ((line = csvReader.readNext()) != null)
		    {
		    	if (line[3].toLowerCase().contains(username.toLowerCase()))
		    		ret = line[2]+" "+line[1];
		    }
		    
		    ret = ret.toLowerCase();
		    StringTokenizer st = new StringTokenizer(ret);
		    String aux_ret = "";
		    
		    while(st.hasMoreTokens())
		    	aux_ret = aux_ret+" "+capitalize(st.nextToken());
		    ret = aux_ret.trim();
		    
			csvReader.close();
			reader.close();
		    
		return ret;
	}
	
	private static String capitalize(String str) {
	    if(str == null || str.isEmpty()) {
	        return str;
	    }

	    return str.substring(0, 1).toUpperCase() + str.substring(1);
	}
	
	public static void main(String[] argv) throws CsvValidationException, IOException
	{
		System.out.println(getUfficioFromUsername("segnalazioni_test"));
		System.out.println(getRuoloFromUsername("segnalazioni_test"));
		System.out.println(getNomeCognomeFromUsername("segnalazioni_test"));
	}
	
}
