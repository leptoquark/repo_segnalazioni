package it.anac.segnalazioni.backoffice.db.model;

/**
 * @author Giancarlo Carbone
 *
 */
import java.util.Date;
import java.util.List;
import java.util.ArrayList;

public class SegnalazioneRpct extends Segnalazione {
	
	// Ente segnalato (obbligatorio)
	private Organizzazione ente;
	
	// Elenco di file allegati comprovante le attivita svolte da RPCT per assicurare adempimento obbligo (obbligatorio)
	private List<String> elencoAttivita;
	
	// Elenco di file allegati contenente le attestazioni OIV (obbligatorio)
	private List<String> elencoFileOiv;
	
	// Soggetti inadempienti (obbligatorio)
	private List<SoggettoInadempiente> soggetti;
	
	public SegnalazioneRpct() {};
	
	/**
	 * 
	 * @param segnalante Soggetto che invia la segnalazione
	 * @param data       Data della segnalazione
	 * @param ente       Ente segnalato
	 */
	public SegnalazioneRpct(Segnalante segnalante, Date data, Organizzazione ente) {
		super(segnalante, data, "RPCT");
		
		this.ente = ente;
		this.elencoAttivita = new ArrayList<String>();
		this.elencoFileOiv = new ArrayList<String>();
		this.soggetti = new ArrayList<SoggettoInadempiente>();
	}

	public Organizzazione getEnte() {
		return ente;
	}

	public void setEnte(Organizzazione enteSegnalato) {
		this.ente = enteSegnalato;
	}

	public List<SoggettoInadempiente> getSoggetti() {
		return soggetti;
	}
	
	public void addSoggetto(SoggettoInadempiente soggetto) {
		this.soggetti.add(soggetto);
	}

	public List<String> getElencoAttivita() {
		return elencoAttivita;
	}

	public List<String> getElencoFileOiv() {
		return elencoFileOiv;
	}
	
	public void addAttivita(String attivita) {
		this.elencoAttivita.add(attivita);
	}
	
	public void addFileOiv(String fileOiv) {
		this.elencoFileOiv.add(fileOiv);
	}
	
}
