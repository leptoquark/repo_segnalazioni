package it.anac.segnalazioni.backoffice.db.model;

import java.util.Date;
import java.util.List;

public class Backoffice {

	private Date lastupdate;
	private String stato;
	private List<Ufficio> uffici;

	public List<Ufficio> getUffici() {
		return uffici;
	}
	public void setUffici(List<Ufficio> uffici) {
		this.uffici = uffici;
	}
	public Date getLastupdate() {
		return lastupdate;
	}
	public void setLastupdate(Date lastupdate) {
		this.lastupdate = lastupdate;
	}
	public String getStato() {
		return stato;
	}
	public void setStato(String stato) {
		this.stato = stato;
	}
}
