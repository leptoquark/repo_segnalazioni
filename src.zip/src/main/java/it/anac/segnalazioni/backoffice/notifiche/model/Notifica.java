package it.anac.segnalazioni.backoffice.notifiche.model;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "notifiche")
public class Notifica {
	
	private Date data;
	private Messaggio messaggio;
	private List<Destinatario> destinatari;
	private Tipo tipo;
	private boolean inviata;
	
	public boolean isInviata() {
		return inviata;
	}
	public void setInviata(boolean inviata) {
		this.inviata = inviata;
	}
	public Tipo getTipo() {
		return tipo;
	}
	public void setTipo(Tipo tipo) {
		this.tipo = tipo;
	}
	
	public void setData(Date data) {
		this.data = data;
	}
	public Date getData() {
		return data;
	}
	public Messaggio getMessaggio() {
		return messaggio;
	}
	public void setMessaggio(Messaggio messaggio) {
		this.messaggio = messaggio;
	}
	public List<Destinatario> getDestinatari() {
		return destinatari;
	}
	public void setDestinatari(List<Destinatario> destinatari) {
		this.destinatari = destinatari;
	}
	
	public Notifica()
	{
		this.data = new Date();
	}
}
