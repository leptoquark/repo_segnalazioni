package it.anac.segnalazioni.backoffice.db.model;

public class BackofficeRecord
{
	private Backoffice backoffice;

	public Backoffice getBackoffice() {
		return backoffice;
	}

	public void setBr(Backoffice backoffice) {
		this.backoffice = backoffice;
	}
	
}
