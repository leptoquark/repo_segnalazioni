package it.anac.segnalazioni.backoffice.web.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import it.anac.segnalazioni.backoffice.db.model.Carenza;
import it.anac.segnalazioni.backoffice.db.model.Segnalazione;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneAppalto;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneCorruzione;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneIncarichi;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneRecord;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneRpct;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneTrasparenza;
import it.anac.segnalazioni.backoffice.db.model.Ufficio;
import it.anac.segnalazioni.backoffice.web.model.SegnalazioneTable;
import it.anac.segnalazioni.backoffice.web.model.SegnalazioneTableAnticorruzione;
import it.anac.segnalazioni.backoffice.web.model.SegnalazioneTableAppalto;
import it.anac.segnalazioni.backoffice.web.model.SegnalazioneTableIncarichi;
import it.anac.segnalazioni.backoffice.web.model.SegnalazioneTableTrasparenza;

public class Mapper {

	public static SegnalazioneTableTrasparenza segnalazioneTrasparenzaMapper(Segnalazione segnalazione, String stato, List<Ufficio> uffici, String ufficio)
	{
		SegnalazioneTable aux = segnalazioneMapper(segnalazione, stato, uffici, ufficio);
		SegnalazioneTableTrasparenza stt = new SegnalazioneTableTrasparenza();
		stt.setProtocollo(aux.getProtocollo());
		stt.setSegnalante(aux.getSegnalante());
		stt.setQualifica(aux.getQualifica());
		stt.setEnte_segnalante(aux.getEnte_segnalante());
		stt.setEnte_segnalato(aux.getEnte_segnalato());
		stt.setData(aux.getData());
		stt.setGg(aux.getGg());
		stt.setArea(aux.getArea());
		stt.setStato(aux.getStato());
		stt.setDataChiusura(aux.getDataChiusura());
		
		stt.setTipo_ente(((SegnalazioneTrasparenza)segnalazione).getEnte().getTipoEnte());
		
		List<Carenza> carenze = ((SegnalazioneTrasparenza)segnalazione).getCarenze();
		String carenze_aux = "";
		
		for (int i=0; i<carenze.size(); i++)
			if (i==carenze.size()-1)
				carenze_aux = carenze_aux + carenze.get(i).getSezione();
			else
				carenze_aux = carenze_aux + carenze.get(i).getSezione()+" - ";
		
		stt.setSezione_trasparenza(carenze_aux);
				
		stt.setOggetto_segnalazione(aux.getOggetto_segnalazione());
		stt.setNome_segnalante(aux.getNome_segnalante());
		stt.setCognome_segnalante(aux.getCognome_segnalante());
		stt.setCf_segnalante(aux.getCf_segnalante());
		
		stt.setProtocolloChiusura(aux.getProtocolloChiusura());
		
		stt.setUffici(aux.getUffici());
						
		return stt;
	}
	
	public static SegnalazioneTableIncarichi segnalazioneIncarichiMapper(Segnalazione segnalazione, String stato, List<Ufficio> uffici, String ufficio)
	{
		SegnalazioneTable aux = segnalazioneMapper(segnalazione, stato, uffici, ufficio);
		SegnalazioneTableIncarichi sti = new SegnalazioneTableIncarichi();
		sti.setProtocollo(aux.getProtocollo());
		sti.setSegnalante(aux.getSegnalante());
		sti.setQualifica(aux.getQualifica());
		sti.setEnte_segnalante(aux.getEnte_segnalante());
		sti.setEnte_segnalato(aux.getEnte_segnalato());
		sti.setData(aux.getData());
		sti.setGg(aux.getGg());
		sti.setArea(aux.getArea());
		sti.setStato(aux.getStato());
		sti.setDataChiusura(aux.getDataChiusura());
		
		sti.setFattispecie(((SegnalazioneIncarichi)segnalazione).getFattispecie());
		if (((SegnalazioneIncarichi)segnalazione).isArticolo3())
			sti.setArt3("Sì");
		else
			sti.setArt3("No");
		
		sti.setOggetto_segnalazione(aux.getOggetto_segnalazione());
		sti.setNome_segnalante(aux.getNome_segnalante());
		sti.setCognome_segnalante(aux.getCognome_segnalante());
		sti.setCf_segnalante(aux.getCf_segnalante());
		
		sti.setProtocolloChiusura(aux.getProtocolloChiusura());
		
		sti.setUffici(aux.getUffici());
						
		return sti;
	}
	
	
	public static SegnalazioneTableAnticorruzione segnalazioneAnticorruzioneMapper(Segnalazione segnalazione, String stato, List<Ufficio> uffici, String ufficio)
	{
		SegnalazioneTable aux = segnalazioneMapper(segnalazione, stato, uffici, ufficio);
		SegnalazioneTableAnticorruzione sta = new SegnalazioneTableAnticorruzione();
		sta.setProtocollo(aux.getProtocollo());
		sta.setSegnalante(aux.getSegnalante());
		sta.setQualifica(aux.getQualifica());
		sta.setEnte_segnalante(aux.getEnte_segnalante());
		sta.setEnte_segnalato(aux.getEnte_segnalato());
		sta.setData(aux.getData());
		sta.setGg(aux.getGg());
		sta.setArea(aux.getArea());
		sta.setStato(aux.getStato());
		sta.setSegnalato(((SegnalazioneCorruzione)segnalazione).getEnte().getDenominazione());
		sta.setQuestione(((SegnalazioneCorruzione)segnalazione).getQuestione());
		sta.setDataChiusura(aux.getDataChiusura());
		
		sta.setOggetto_segnalazione(aux.getOggetto_segnalazione());
		sta.setNome_segnalante(aux.getNome_segnalante());
		sta.setCognome_segnalante(aux.getCognome_segnalante());
		sta.setCf_segnalante(aux.getCf_segnalante());
		
		sta.setProtocolloChiusura(aux.getProtocolloChiusura());
		
		sta.setUffici(aux.getUffici());
						
		return sta;
	}
	
	public static SegnalazioneTableAppalto segnalazioneAppaltoMapper(Segnalazione segnalazione, String stato, List<Ufficio> uffici, String ufficio)
	{
		SegnalazioneTable aux = segnalazioneMapper(segnalazione, stato, uffici, ufficio);
		SegnalazioneTableAppalto sta = new SegnalazioneTableAppalto();
		sta.setProtocollo(aux.getProtocollo());
		sta.setSegnalante(aux.getSegnalante());
		sta.setQualifica(aux.getQualifica());
		sta.setEnte_segnalante(aux.getEnte_segnalante());
		sta.setEnte_segnalato(aux.getEnte_segnalato());
		sta.setData(aux.getData());
		sta.setGg(aux.getGg());
		sta.setArea(aux.getArea());
		sta.setStato(aux.getStato());
		sta.setStazioneAppaltante(((SegnalazioneAppalto)segnalazione).getSa().getDenominazione());
		sta.setCig(((SegnalazioneAppalto)segnalazione).getCig());
		sta.setOe(((SegnalazioneAppalto)segnalazione).getOe().getDenominazione());
		sta.setAmbito(((SegnalazioneAppalto)segnalazione).getAmbito());
		sta.setImporto(""+((SegnalazioneAppalto)segnalazione).getImporto());
		sta.setProceduraAffidamento(((SegnalazioneAppalto)segnalazione).getProcedura());
		sta.setFase(((SegnalazioneAppalto)segnalazione).getFase());
		sta.setRup(((SegnalazioneAppalto)segnalazione).getRup().getNome()+" "+((SegnalazioneAppalto)segnalazione).getRup().getCognome());
		sta.setOggettoContratto(((SegnalazioneAppalto)segnalazione).getOggettoContratto());	
		sta.setDataChiusura(aux.getDataChiusura());
		
		sta.setOggetto_segnalazione(aux.getOggetto_segnalazione());
		sta.setNome_segnalante(aux.getNome_segnalante());
		sta.setCognome_segnalante(aux.getCognome_segnalante());
		sta.setCf_segnalante(aux.getCf_segnalante());
		
		sta.setProtocolloChiusura(aux.getProtocolloChiusura());
		
		sta.setUffici(aux.getUffici());
		
		return sta;
	}
	
	public static SegnalazioneTable segnalazioneMapper(Segnalazione segnalazione, String stato, List<Ufficio> uffici, String ufficio)
	{
		SegnalazioneTable ret = new SegnalazioneTable();
				
		ret.setSegnalante(segnalazione.getSegnalante().getNome()+" "+segnalazione.getSegnalante().getCognome());
		ret.setNome_segnalante(segnalazione.getSegnalante().getNome());
		ret.setCognome_segnalante(segnalazione.getSegnalante().getCognome());
		ret.setCf_segnalante(segnalazione.getSegnalante().getCodiceFiscale());
		ret.setQualifica(segnalazione.getSegnalante().getQualifica());
		
		String oggetto_aux = segnalazione.getOggetto();
		if (oggetto_aux==null)
			oggetto_aux = "N.D.";
		ret.setOggetto_segnalazione(oggetto_aux);
				
		
		String area = "";
		
		if (segnalazione instanceof SegnalazioneRpct)
		{
			ret.setEnte_segnalato(((SegnalazioneRpct)segnalazione).getEnte().getDenominazione());
			area = "RPCT";
		}
		else if (segnalazione instanceof SegnalazioneIncarichi)
		{
			ret.setEnte_segnalato(((SegnalazioneIncarichi)segnalazione).getEnte().getDenominazione());
			area = "Incarichi";
		}
		else if (segnalazione instanceof SegnalazioneAppalto) {
			ret.setEnte_segnalato(((SegnalazioneAppalto)segnalazione).getSa().getDenominazione());
			area = "Appalti";
		}
		else if (segnalazione instanceof SegnalazioneTrasparenza)
		{
			ret.setEnte_segnalato(((SegnalazioneTrasparenza)segnalazione).getEnte().getDenominazione());
			area = "Trasparenza";
		}
		else if (segnalazione instanceof SegnalazioneCorruzione)
		{
			ret.setEnte_segnalato(((SegnalazioneCorruzione)segnalazione).getEnte().getDenominazione());
			area = "Corruzione";
		}
		
		ret.setEnte_segnalante((segnalazione).getSegnalante().getEnte().getDenominazione());
		
		String pattern = "dd/MM/yyyy";
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
		ret.setData(simpleDateFormat.format(segnalazione.getData()));
		
		///////////////

		Date chiusura = new Date();
		String protocolloChiusura = "";
		if (stato.equalsIgnoreCase("chiuso"))
		{
			for(int i=0; i<uffici.size(); i++)
				if (uffici.get(i).getDenominazione().equalsIgnoreCase(ufficio) || ufficio.equals(""))
				{
					chiusura = uffici.get(i).getDataChiusuraDate();
					protocolloChiusura = uffici.get(i).getProtocolloChiusura();
				}
		}
		
		ret.setUffici(uffici);
		
		if (chiusura==null)
			chiusura = new Date();

		long diffInMillies = Math.abs(chiusura.getTime()
				- segnalazione.getData().getTime());
	    long gg = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
	    
	    /////////////////
		
		ret.setGg(Integer.valueOf(""+gg));
		
		ret.setArea(area);
		ret.setProtocolloChiusura(protocolloChiusura);
			
		ret.setDataChiusura(simpleDateFormat.format(chiusura));
		
		ret.setStato(stato);

		return ret;
	}
	
	public static SegnalazioneTable segnalazioneMapperAll(Segnalazione segnalazione, String stato, List<Ufficio> uffici)
	{
		return segnalazioneMapper(segnalazione,stato,uffici,"");
	}
	
	public static List<SegnalazioneTable> segnalazioniMapper(List<SegnalazioneRecord> segnalazioni, String ufficio, int giorni_soglia)
	{
		List<SegnalazioneTable> ret = new LinkedList<SegnalazioneTable>();
		for (int i=0; i<segnalazioni.size(); i++)
		{
			
			if (segnalazioni.get(i).getBackoffice()!=null)
			{
				SegnalazioneTable st = Mapper.segnalazioneMapperAll(
													segnalazioni.get(i).getSegnalazione(),
													segnalazioni.get(i).getBackoffice().getStato(),
													segnalazioni.get(i).getBackoffice().getUffici()
													);
				st.setProtocollo(segnalazioni.get(i).getProtocollo());
				st.setIdSottomissione(segnalazioni.get(i).getIdSottomissione());
				st.setUfficioCompetente(getAcronimo(segnalazioni.get(i).getUfficioCompetente()));
				st.setSoglia(st.getGg()>giorni_soglia);
				ret.add(st);
			}
		}
		return ret;
	}
	
	public static List<SegnalazioneTableAppalto> segnalazioniAppaltoMapper(List<SegnalazioneRecord> segnalazioni, String ufficio, int giorni_soglia)
	{
		List<SegnalazioneTableAppalto> ret = new LinkedList<SegnalazioneTableAppalto>();
		for (int i=0; i<segnalazioni.size(); i++)
		{
			boolean filter = false;
			
			if (segnalazioni.get(i).getBackoffice()!=null)
			{
				List<Ufficio> uffici_filter = segnalazioni.get(i).getBackoffice().getUffici();
				for(int c=0; c<uffici_filter.size(); c++)
				{
					if (uffici_filter.get(c).getDenominazione()!=null)
						if (uffici_filter.get(c).getDenominazione().equalsIgnoreCase(ufficio))
							filter=true;
				}
				
				
				if (segnalazioni.get(i).getBackoffice()!=null)
					if (segnalazioni.get(i).getSegnalazione() instanceof SegnalazioneAppalto)
						if (filter)
				{
					SegnalazioneTableAppalto st = Mapper.segnalazioneAppaltoMapper(
														segnalazioni.get(i).getSegnalazione(),
														segnalazioni.get(i).getBackoffice().getStato(),
														segnalazioni.get(i).getBackoffice().getUffici(),
														ufficio
														);
					st.setProtocollo(segnalazioni.get(i).getProtocollo());
					st.setIdSottomissione(segnalazioni.get(i).getIdSottomissione());
					st.setUfficioCompetente(getAcronimo(segnalazioni.get(i).getUfficioCompetente()));
					st.setSoglia(st.getGg()>giorni_soglia);
					ret.add(st);
				}
			}
		}
		return ret;
	}
	
	public static List<SegnalazioneTableTrasparenza> segnalazioniTrasparenzaMapper(List<SegnalazioneRecord> segnalazioni, String ufficio, int giorni_soglia)
	{
		List<SegnalazioneTableTrasparenza> ret = new LinkedList<SegnalazioneTableTrasparenza>();
		for (int i=0; i<segnalazioni.size(); i++)
		{
			boolean filter = false;
			
			if (segnalazioni.get(i).getBackoffice()!=null)
			{
				List<Ufficio> uffici_filter = segnalazioni.get(i).getBackoffice().getUffici();
				for(int c=0; c<uffici_filter.size(); c++)
				{
					if (uffici_filter.get(c).getDenominazione()!=null)
						if (uffici_filter.get(c).getDenominazione().equalsIgnoreCase(ufficio))
							filter=true;
				}
				
				
				if (segnalazioni.get(i).getBackoffice()!=null)
					if (segnalazioni.get(i).getSegnalazione() instanceof SegnalazioneTrasparenza)
						if (filter)
				{
					SegnalazioneTableTrasparenza st = Mapper.segnalazioneTrasparenzaMapper(
														segnalazioni.get(i).getSegnalazione(),
														segnalazioni.get(i).getBackoffice().getStato(),
														segnalazioni.get(i).getBackoffice().getUffici(),
														ufficio
														);
					st.setProtocollo(segnalazioni.get(i).getProtocollo());
					st.setIdSottomissione(segnalazioni.get(i).getIdSottomissione());
					st.setUfficioCompetente(getAcronimo(segnalazioni.get(i).getUfficioCompetente()));
					st.setSoglia(st.getGg()>giorni_soglia);
					ret.add(st);
				}
			}
		}
		return ret;
	}
	
	public static List<SegnalazioneTableAnticorruzione> segnalazioniAnticorruzioneMapper(List<SegnalazioneRecord> segnalazioni, String ufficio, int giorni_soglia)
	{
		List<SegnalazioneTableAnticorruzione> ret = new LinkedList<SegnalazioneTableAnticorruzione>();
		for (int i=0; i<segnalazioni.size(); i++)
		{
			boolean filter = false;
			
			if (segnalazioni.get(i).getBackoffice()!=null)
			{
				List<Ufficio> uffici_filter = segnalazioni.get(i).getBackoffice().getUffici();
				for(int c=0; c<uffici_filter.size(); c++)
					if (uffici_filter.get(c).getDenominazione()!=null)
						if (uffici_filter.get(c).getDenominazione().equalsIgnoreCase(ufficio))
							filter=true;
				
				if (segnalazioni.get(i).getBackoffice()!=null)
					if (segnalazioni.get(i).getSegnalazione() instanceof SegnalazioneCorruzione)
						if (filter)
				{
						SegnalazioneTableAnticorruzione st = Mapper.segnalazioneAnticorruzioneMapper(
														segnalazioni.get(i).getSegnalazione(),
														segnalazioni.get(i).getBackoffice().getStato(),
														segnalazioni.get(i).getBackoffice().getUffici(),
														ufficio
														);
					st.setProtocollo(segnalazioni.get(i).getProtocollo());
					st.setIdSottomissione(segnalazioni.get(i).getIdSottomissione());
					st.setUfficioCompetente(getAcronimo(segnalazioni.get(i).getUfficioCompetente()));
					st.setSoglia(st.getGg()>giorni_soglia);
					ret.add(st);
				}
			}
		}
		return ret;
	}
	
	public static List<SegnalazioneTableIncarichi> segnalazioniIncarichiMapper(List<SegnalazioneRecord> segnalazioni, String ufficio, int giorni_soglia)
	{
		List<SegnalazioneTableIncarichi> ret = new LinkedList<SegnalazioneTableIncarichi>();
		for (int i=0; i<segnalazioni.size(); i++)
		{
			boolean filter = false;
			
			if (segnalazioni.get(i).getBackoffice()!=null)
			{
				List<Ufficio> uffici_filter = segnalazioni.get(i).getBackoffice().getUffici();
			
				for(int c=0; c<uffici_filter.size(); c++)
					if (uffici_filter.get(c).getDenominazione()!=null)
						if (uffici_filter.get(c).getDenominazione().equalsIgnoreCase(ufficio))
							filter=true;
							
				if (segnalazioni.get(i).getBackoffice()!=null)
					if (segnalazioni.get(i).getSegnalazione() instanceof SegnalazioneIncarichi)
						if (filter)
				{
							SegnalazioneTableIncarichi st = Mapper.segnalazioneIncarichiMapper(
														segnalazioni.get(i).getSegnalazione(),
														segnalazioni.get(i).getBackoffice().getStato(),
														segnalazioni.get(i).getBackoffice().getUffici(),
														ufficio
														);
					st.setProtocollo(segnalazioni.get(i).getProtocollo());
					st.setIdSottomissione(segnalazioni.get(i).getIdSottomissione());
					st.setUfficioCompetente(getAcronimo(segnalazioni.get(i).getUfficioCompetente()));
					st.setSoglia(st.getGg()>giorni_soglia);
					ret.add(st);
				}
			}
		}
		
		return ret;
	}
	
	private static final String UVMACT = "UVMACT";
	private static final String UVCP = "UVCP";
	private static final String UVIF = "UVIF";
	private static final String UVLA = "UVLA";
	private static final String UVS = "UVS";
	private static final String UVSF = "UVSF";
	private static final String USAN = "USAN";

	public static String getAcronimo(String ufficioCompetente)
	{
		String ret = "N.D.";
				
		if (ufficioCompetente.contains(UVMACT)) ret = UVMACT;
		if (ufficioCompetente.contains(UVCP)) ret =  UVCP;
		if (ufficioCompetente.contains(UVIF)) ret =  UVIF;
		if (ufficioCompetente.contains(UVLA)) ret = UVLA;
		if (ufficioCompetente.contains(UVS)) ret = UVS;
		if (ufficioCompetente.contains(UVSF)) ret = UVSF;
		if (ufficioCompetente.contains(USAN)) ret = USAN;
		
		return ret;
	}
}
