package it.anac.segnalazioni.backoffice.db.model;

import java.util.Date;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import it.anac.segnalazioni.backoffice.web.controller.IsoDateDeSerializer;

public class Incarico {
	
	private String denominazione;
	
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date dataAssunzione;
	
	private boolean inCorso;
	
	public Incarico() {};
	
	public Incarico(String incarico, boolean inCorso) {
		this.denominazione = incarico;
		this.inCorso = inCorso;
	}
	
	public Incarico(String incarico, Date dataAssunzione, boolean inCorso) {
		this.denominazione = incarico;
		this.inCorso = inCorso;
		this.dataAssunzione = dataAssunzione;
	}

	public String getDenominazione() {
		return denominazione;
	}

	public void setDenominazione(String incarico) {
		this.denominazione = incarico;
	}

	public Date getDataAssunzione() {
		return dataAssunzione;
	}

	public void setDataAssunzione(Date dataAssunzione) {
		this.dataAssunzione = dataAssunzione;
	}

	public boolean isInCorso() {
		return inCorso;
	}

	public void setInCorso(boolean inCorso) {
		this.inCorso = inCorso;
	}
}
