package it.anac.segnalazioni.backoffice.web.model;

public class SegnalazioneTableIncarichi extends SegnalazioneTable {
	
	private String fattispecie;
	private String art3;
	
	public String getFattispecie() {
		return fattispecie;
	}
	public void setFattispecie(String fattispecie) {
		this.fattispecie = fattispecie;
	}
	public String getArt3() {
		return art3;
	}
	public void setArt3(String art3) {
		this.art3 = art3;
	}	
}