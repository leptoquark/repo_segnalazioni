package it.anac.segnalazioni.backoffice.service;

import java.io.IOException;
import java.util.List;

import org.apache.cxf.endpoint.Client;
import org.apache.cxf.frontend.ClientProxy;
import org.apache.cxf.transport.http.HTTPConduit;
import org.apache.cxf.transports.http.configuration.HTTPClientPolicy;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import it.anac.segnalazioni.client.protocollo.IdentificazioneType;
import it.anac.segnalazioni.client.protocollo.ProtocolloViewType;
import it.anac.segnalazioni.client.protocollo.ProtocolloWS;
import it.anac.segnalazioni.client.protocollo.ProtocolloWS_Service;
import it.anac.segnalazioni.client.protocollo.RicercaDocRequestType;
import it.anac.segnalazioni.client.protocollo.RicercaRequestType;
import it.anac.segnalazioni.client.protocollo.RicercaResponseType;
import it.anac.segnalazioni.client.protocollo.RicercaDocResponseType;

@Service
public class ProtocolloService {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProtocolloService.class);
	
	@Value("${protocollo.ws.utente}")
	protected String utente;
	
	@Value("${protocollo.ws.password}")
    protected String password;
		
	public ProtocolloBaseResponse ricercaDocumenti(String identificazioneAoo,
											   String identificazioneUfficio,
											   int numero,
											   int anno,
											   String utenteRichiedente) throws IOException {
		
		ProtocolloWS_Service service = new ProtocolloWS_Service();
		ProtocolloWS client = service.getProtocolloWSSOAP();
		
		Client clientp = ClientProxy.getClient(client);
		HTTPConduit http = (HTTPConduit) clientp.getConduit();
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(0);
		httpClientPolicy.setReceiveTimeout(0);
		http.setClient(httpClientPolicy);

		RicercaDocRequestType ricercaDocRequest = new RicercaDocRequestType();
		
		IdentificazioneType identificazione = new IdentificazioneType();
		identificazione.setAoo(identificazioneAoo);
		identificazione.setUfficio(identificazioneUfficio);
		identificazione.setUtente(utente);
		identificazione.setPassword(password);
		
		ricercaDocRequest.setAnnoProtocollo(anno);
		ricercaDocRequest.setIdentificazione(identificazione);
		ricercaDocRequest.setNumeroProtocollo(numero);
		ricercaDocRequest.setUtenteRichiedente(utenteRichiedente);
		
		RicercaDocResponseType aux = null;
		try {
			aux = client.ricercaDocumenti(ricercaDocRequest);
		} catch (Exception ex)
		{
			aux = new RicercaDocResponseType();
			aux.setEsito("TIMEOUT");
			aux.setDescrizioneEsito("Errore: "+ex.getStackTrace().toString());
		}
		
		ProtocolloBaseResponse ret = new ProtocolloBaseResponse();
		ret.setEsito(aux.getEsito());
		ret.setMessaggio(aux.getDescrizioneEsito());
				
		return ret;
	}
	
	public ProtocolloRicercaResponse ricercaProtocollo(String identificazioneAoo,
			   String identificazioneUfficio,
			   int numero,
			   int anno,
			   String utenteRichiedente)
	{
		ProtocolloRicercaResponse ret = new ProtocolloRicercaResponse();
		
		
		ProtocolloWS_Service service = new ProtocolloWS_Service();
		ProtocolloWS client = service.getProtocolloWSSOAP();
		
		Client clientp = ClientProxy.getClient(client);
		HTTPConduit http = (HTTPConduit) clientp.getConduit();
		HTTPClientPolicy httpClientPolicy = new HTTPClientPolicy();
		httpClientPolicy.setConnectionTimeout(0);
		httpClientPolicy.setReceiveTimeout(0);
		http.setClient(httpClientPolicy);

		RicercaRequestType ricercaProtocolloRequest = new RicercaRequestType();
		
		IdentificazioneType identificazione = new IdentificazioneType();
		identificazione.setAoo(identificazioneAoo);
		identificazione.setUfficio(identificazioneUfficio);
		identificazione.setUtente(utente);
		identificazione.setPassword(password);
		
		ricercaProtocolloRequest.setIdentificazione(identificazione);
		ricercaProtocolloRequest.setAnnoProtocolloDa(anno);
		ricercaProtocolloRequest.setNumeroProtocolloDa(numero);
		
		RicercaResponseType aux = null;
		try {
			aux = client.ricercaProtocolli(ricercaProtocolloRequest);
			LOGGER.info("Ricerca per protocollo "+numero+"/"+anno);
			LOGGER.info("Esito: "+aux.getEsito());
			LOGGER.info("Descrizione esito: "+aux.getDescrizioneEsito());
		} catch (Exception ex)
		{
			aux = new RicercaResponseType();
			aux.setEsito("Errore nella richiesta SOAP");
			aux.setDescrizioneEsito("Errore: "+ex.getStackTrace().toString());
		}
		
		List<ProtocolloViewType> pvt_list = aux.getProtocolli();
		
		ProtocolloBaseResponse pbr = new ProtocolloBaseResponse();
		pbr.setEsito(aux.getEsito());
		pbr.setMessaggio(aux.getDescrizioneEsito());
		
		ret.setProtocolloBaseResponse(pbr);
		ret.setProtocolli(pvt_list);
		
		return ret;
	}
}