package it.anac.segnalazioni.backoffice.rest;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import it.anac.segnalazioni.backoffice.service.ProtocolloService;
import it.anac.segnalazioni.backoffice.web.controller.Autorizzazione;
import it.anac.segnalazioni.client.protocollo.ProtocolloViewType;

@RestController
@RequestMapping(path="/ws")
public class ProtocolloRestService extends Autorizzazione {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ProtocolloRestService.class);
	
	@Autowired
	ProtocolloService ps;
	
	@Value("${protocollo.ws.aoo}")
    private String aoo;
	
	@Value("${protocollo.ws.ufficio}")
    private String ufficio;
	
	@Value("${backoffice.test}")
    private boolean test;
		
	@GetMapping("/permessoUtente")
	public boolean getPermessoUtente(int numero, int anno) throws IOException
	{
		
		
		if (test)
		{
			try {
				TimeUnit.SECONDS.sleep(3);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			return true;
		}
		
		String username = autorizza(super.USER);
		
		LOGGER.info("Verifico il permesso per l'utente "+username);
		
        String esito = (ps.ricercaDocumenti(aoo,
        									ufficio,
        									numero,
        									anno,
        									username)).getEsito();
        
        LOGGER.info("Esito: "+esito);
        LOGGER.info("Risultato: "+esito.equalsIgnoreCase("0000"));      
        
        return esito.equalsIgnoreCase("0000");
	}
	
	@GetMapping("/ricercaProtocollo")
	public ProtocolloViewType getRicercaProtocollo(int numero, int anno) throws IOException
	{
		String username = autorizza(super.USER);
		return ps.ricercaProtocollo(aoo,
        					 		ufficio,
        					 		numero,
        					 		anno,
        					 		username).getProtocolli().get(0);
        
	}
}
