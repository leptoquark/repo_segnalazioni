package it.anac.segnalazioni.backoffice.db;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.opencsv.exceptions.CsvValidationException;

import fr.opensagres.xdocreport.document.json.JSONObject;
import it.anac.segnalazioni.backoffice.db.model.Assegnatario;
import it.anac.segnalazioni.backoffice.db.model.Backoffice;
import it.anac.segnalazioni.backoffice.db.model.BackofficeRecord;
import it.anac.segnalazioni.backoffice.db.model.Segnalazione;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneAppalto;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneCorruzione;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneIncarichi;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneRecord;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneRpct;
import it.anac.segnalazioni.backoffice.db.model.SegnalazioneTrasparenza;
import it.anac.segnalazioni.backoffice.db.model.Ufficio;

@RestController
public class MongoSubmission {
	
	@Autowired
	private MongoTemplate mongoTemplate;
		
	@Value("${backoffice.test}")
    private boolean test;
	
	public String setChiusura(String idSubmission,
							  String ufficio,
							  String utente,
							  String protocolloChiusura,
							  String motivazione,
							  String priorita) throws JsonMappingException, JsonProcessingException
	{
		Query query = new Query();	
		query.addCriteria(Criteria.where("idSottomissione").is(idSubmission));
		
		JSONObject res = mongoTemplate.findOne(query, JSONObject.class,"segnalazioni");
		ObjectMapper objectMapper = new ObjectMapper();
		JsonNode jsonNode = objectMapper.readTree(res.toString());
		String prot_res = jsonNode.get("protocollo").asText();	
		
		mongoTemplate.updateFirst(query, Update.update("backoffice.lastupdate", new Date()), BackofficeRecord.class,"segnalazioni");
				 
		JsonNode ufficiNode = jsonNode.at("/backoffice").get("uffici");

		int array_ufficio = 0;
		int j=0;
		
		if (ufficiNode.isArray() && !ufficiNode.isEmpty()) {
			for (JsonNode arrNode : ufficiNode)
			{
				Ufficio ufficioAux = new Ufficio();
									
				if (!arrNode.isEmpty())
				{
					if (!arrNode.get("dataChiusura").isEmpty())
					{
						String dataChiusura_aux = arrNode.get("dataChiusura").get("$date").asText();
						ufficioAux.setDataChiusura(dataChiusura_aux);
					} else
						ufficioAux.setDataChiusuraDate(null);
					
					ufficioAux.setProtocolloChiusura(arrNode.get("protocolloChiusura").asText());
   				    ufficioAux.setUtenteModifica(arrNode.get("utenteModifica").asText());
					ufficioAux.setDenominazione(arrNode.get("denominazione").asText());
				}
				
				if (ufficioAux.getDenominazione().contains(ufficio))
					array_ufficio = j;
				
				j++;
			}
		}
				
		int dim = (7+5)-protocolloChiusura.length();
		String zeros = "";
		for (int k=0; k<dim; k++)
			zeros=zeros+"0";
		protocolloChiusura=zeros+protocolloChiusura;
		
		mongoTemplate.updateFirst(query, Update.update("backoffice.uffici."+array_ufficio+".utenteModifica",utente), BackofficeRecord.class,"segnalazioni");
		mongoTemplate.updateFirst(query, Update.update("backoffice.uffici."+array_ufficio+".stato","chiuso"), BackofficeRecord.class,"segnalazioni");
		mongoTemplate.updateFirst(query, Update.update("backoffice.uffici."+array_ufficio+".dataChiusura",new Date()), BackofficeRecord.class,"segnalazioni");
		mongoTemplate.updateFirst(query, Update.update("backoffice.uffici."+array_ufficio+".protocolloChiusura",protocolloChiusura), BackofficeRecord.class,"segnalazioni");
		mongoTemplate.updateFirst(query, Update.update("backoffice.uffici."+array_ufficio+".motivazione",motivazione), BackofficeRecord.class,"segnalazioni");
		mongoTemplate.updateFirst(query, Update.update("backoffice.uffici."+array_ufficio+".priorita",priorita), BackofficeRecord.class,"segnalazioni");
		
		
		// se sono tutti chiuso allora è chiuso anche il figlio
		boolean stato_globlale_chiuso = true;
		if (ufficiNode.isArray() && !ufficiNode.isEmpty()) {
			for (JsonNode arrNode : ufficiNode)
			{
				String stato_aux = arrNode.get("stato").asText();
								
				if (stato_aux.toLowerCase().contains("aperto"))
					stato_globlale_chiuso = false;
			}
		}
		
		if (stato_globlale_chiuso)
		{
			mongoTemplate.updateFirst(query, Update.update("backoffice.stato", "chiuso"), BackofficeRecord.class,"segnalazioni");
			mongoTemplate.updateFirst(query, Update.update("backoffice.dataChiusura", new Date()), BackofficeRecord.class,"segnalazioni");
		}
		
		mongoTemplate.updateFirst(query, Update.update("backoffice.lastupdate", new Date()), BackofficeRecord.class,"segnalazioni");
		
		
		return prot_res;
	}
	
    @GetMapping("/findAll")
	public List<SegnalazioneRecord> findAll() throws ParseException, CsvValidationException, IOException {

		LinkedList<SegnalazioneRecord> segnalazioni = new LinkedList<SegnalazioneRecord>();
    	Query q = new Query();
    	
		List<JSONObject> res = mongoTemplate.find(q,JSONObject.class, "segnalazioni");
	
		for(int i=0; i<res.size(); i++)
		{
			
			Segnalazione aux = null;
			SegnalazioneRecord sr = new SegnalazioneRecord();
				
			ObjectMapper objectMapper = new ObjectMapper();
						
			JsonNode jsonNode = objectMapper.readTree(res.get(i).toString());
			
				
			if (jsonNode.at("/segnalazione").get("area")!=null)
			{				
				boolean appalto = jsonNode.at("/segnalazione").get("area").toString().equals("\"Appalto\"");
				boolean corruzione = jsonNode.at("/segnalazione").get("area").toString().equals("\"Anticorruzione\"");;
				boolean incarichi = jsonNode.at("/segnalazione").get("area").toString().equals("\"Incarichi\"");;
				boolean trasparenza = jsonNode.at("/segnalazione").get("area").toString().equals("\"Trasparenza\"");;
				
				boolean rpct = trasparenza &&
									(jsonNode.at("/segnalazione").get("tiposegnalazione")!=null &&
										jsonNode.at("/segnalazione").get("tiposegnalazione").equals("rpct")); 
				
				
							
				if (rpct)
				{			
					aux = objectMapper.readValue(jsonNode.at("/segnalazione").toString(), SegnalazioneRpct.class);
					
				}
				else if (incarichi)
				{
					aux = objectMapper.readValue(jsonNode.at("/segnalazione").toString(), SegnalazioneIncarichi.class);
				}
				else if (appalto)
				{
					aux = objectMapper.readValue(jsonNode.at("/segnalazione").toString(), SegnalazioneAppalto.class);
				}
				else if (corruzione)
				{
					aux = objectMapper.readValue(jsonNode.at("/segnalazione").toString(), SegnalazioneCorruzione.class);					
				}
				else if (trasparenza)
				{
					aux = objectMapper.readValue(jsonNode.at("/segnalazione").toString(), SegnalazioneTrasparenza.class);
				}
				
				if (aux==null)
					aux = objectMapper.readValue(jsonNode.at("/segnalazione").toString(), SegnalazioneRpct.class);
							
				sr.setSegnalazione(aux);
				sr.setIdSottomissione(jsonNode.get("idSottomissione").asText());
				sr.setProtocollo(jsonNode.get("protocollo").asText());
				
				sr.setUfficioCompetente(jsonNode.get("ufficioCompetente").asText());
				
				if (!jsonNode.at("/backoffice").isNull())
					if (jsonNode.at("/backoffice").get("stato")!=null)
				{
					Backoffice backoffice = new Backoffice();
				
					backoffice.setStato(jsonNode.at("/backoffice").get("stato").asText());
					
					String lastupdate_aux = jsonNode.at("/backoffice").get("lastupdate").get("$date").asText();
					LocalDate lastupdate_localDate = LocalDate.parse(lastupdate_aux, DateTimeFormatter.ISO_DATE_TIME);
					Date lastupdate = Date.from(lastupdate_localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
					backoffice.setLastupdate(lastupdate);
					
					
					List<Ufficio> uffici = new LinkedList<Ufficio>();
										
					JsonNode ufficiNode = jsonNode.at("/backoffice").get("uffici");
										
					if (ufficiNode.isArray() && !ufficiNode.isEmpty()) {
						for (JsonNode arrNode : ufficiNode)
						{
							Ufficio ufficioAux = new Ufficio();
																		
							if (!arrNode.get("dataChiusura").isEmpty())
							{
								String dataChiusura_aux = arrNode.get("dataChiusura").get("$date").asText();
								ufficioAux.setDataChiusura(dataChiusura_aux);
							} else {
								ufficioAux.setDataChiusuraDate(null);
							}
						
							ufficioAux.setProtocolloChiusura(arrNode.get("protocolloChiusura").asText());
							

							ufficioAux.setStato(arrNode.get("stato").asText());
							ufficioAux.setUtenteModifica(arrNode.get("utenteModifica").asText());
							ufficioAux.setDenominazione(arrNode.get("denominazione").asText());
							
							if (arrNode.get("motivazione")!=null)
								ufficioAux.setMotivazione(arrNode.get("motivazione").asText());
							else
								ufficioAux.setMotivazione("");
	
							if (arrNode.get("priorita")!=null)
								ufficioAux.setPriorita(arrNode.get("priorita").asText());
							else
								ufficioAux.setPriorita("");
							
							List<Assegnatario> assegnatari = new LinkedList<Assegnatario>();				
														
							JsonNode assegnatariNode = arrNode.get("assegnatari");
							
							if (assegnatariNode!=null)
								if (!assegnatariNode.isEmpty() && assegnatariNode.isArray())
									for (JsonNode assegnatarioNode : assegnatariNode)
									{
										Assegnatario assegnatario_aux = new Assegnatario();
										if (!assegnatarioNode.isEmpty())
										{	
											assegnatario_aux.setUtenteAssegnatario(assegnatarioNode.get("utenteAssegnatario").asText());
											assegnatario_aux.setStatoAssegnazione(assegnatarioNode.get("statoAssegnazione").asText());
											
																						
											LocalDate dataAssegnazione_localDate = LocalDate.parse(assegnatarioNode.get("dataAssegnazione").get("$date").asText(), DateTimeFormatter.ISO_DATE_TIME);
											Date dataAssegnazione = Date.from(dataAssegnazione_localDate.atStartOfDay(ZoneId.systemDefault()).toInstant());
											
											String pattern = "dd/MM/yyyy";
											SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
											assegnatario_aux.setDataAssegnazione(simpleDateFormat.format(dataAssegnazione));
											
											assegnatari.add(assegnatario_aux);
										}					
									}							
					
							ufficioAux.setAssegnatari(assegnatari);						
							uffici.add(ufficioAux);
						}
						
						backoffice.setUffici(uffici);
						sr.setBackoffice(backoffice);
					}
				
				segnalazioni.add(sr);
				}
			}
		}
		return segnalazioni;
    }
}