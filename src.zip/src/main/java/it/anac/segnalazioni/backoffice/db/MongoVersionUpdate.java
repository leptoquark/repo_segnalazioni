package it.anac.segnalazioni.backoffice.db;

public class MongoVersionUpdate {

}
