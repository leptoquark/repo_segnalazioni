package it.anac.segnalazioni.backoffice.web.controller;

import java.io.IOException;
import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.opencsv.exceptions.CsvValidationException;

import it.anac.segnalazioni.backoffice.db.MongoSubmission;
import it.anac.segnalazioni.backoffice.web.util.FirmUsers;
import it.anac.segnalazioni.backoffice.web.util.Mapper;

@Controller
public class Segnalazioni extends Autorizzazione {
	
	@Value("${backoffice.versione}")
    private String VERSIONE;
	
	@Value("${backoffice.giorni_soglia}")
    private int GIORNI_SOGLIA;
	
	@Autowired
	private MongoSubmission ms;

    @GetMapping(path = "/segnalazioni")
    public String segnalazioni(Model model) throws ParseException, CsvValidationException, IOException {
    	    	
    	String ret = "index";
    	String username = autorizza(super.USER);
    	
    	if (username!=null)
    	{
    		model.addAttribute("segnalazioni",Mapper.segnalazioniMapper(ms.findAll(),"",GIORNI_SOGLIA));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    		model.addAttribute("area","Segnalazioni");
    		ret = "segnalazioni";
    	}
     
        return ret;
    }
    
    @GetMapping(path = "/segnalazioni_appalti")
    public String segnalazioniAppalti(Model model) throws ParseException, CsvValidationException, IOException {
    	
    	String ret = "index";
		
    	String username = autorizza(super.USER);
    	if (username!=null)
    	{
    		model.addAttribute("segnalazioni",Mapper.segnalazioniAppaltoMapper(ms.findAll(),FirmUsers.getUfficioFromUsername(username).toUpperCase(), GIORNI_SOGLIA));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    		model.addAttribute("area","Appalti");
    		ret = "segnalazioni_appalti";
    	}
     
        return ret;
    }
    
    @GetMapping(path = "/segnalazioni_anticorruzione")
    public String segnalazioniAnticorruzione(Model model) throws ParseException, CsvValidationException, IOException {
    	
    	String ret = "index";
		
    	String username = autorizza(super.USER);
    	if (username!=null)
    	{		
    		model.addAttribute("segnalazioni",Mapper.segnalazioniAnticorruzioneMapper(ms.findAll(),FirmUsers.getUfficioFromUsername(username).toUpperCase(), GIORNI_SOGLIA));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    		model.addAttribute("area","Anticorruzione");
    		ret = "segnalazioni_anticorruzione";
    	}
     
        return ret;
    }
    
    @GetMapping(path = "/segnalazioni_incarichi")
    public String segnalazioniIncarichi(Model model) throws ParseException, CsvValidationException, IOException {
    	
    	String ret = "index";
		
    	String username = autorizza(super.USER);
    	if (username!=null)
    	{		
    		model.addAttribute("segnalazioni",Mapper.segnalazioniIncarichiMapper(ms.findAll(),FirmUsers.getUfficioFromUsername(username).toUpperCase(), GIORNI_SOGLIA));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    		model.addAttribute("area","Incarichi");
    		ret = "segnalazioni_incarichi";
    	}
     
        return ret;
    }
    
    @GetMapping(path = "/segnalazioni_trasparenza")
    public String segnalazioniTrasparenza(Model model) throws ParseException, CsvValidationException, IOException {
    	
    	String ret = "index";
		
    	String username = autorizza(super.USER);
    	if (username!=null)
    	{		
    		model.addAttribute("segnalazioni",Mapper.segnalazioniTrasparenzaMapper(ms.findAll(),FirmUsers.getUfficioFromUsername(username).toUpperCase(), GIORNI_SOGLIA));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    		model.addAttribute("area","Trasparenza");
    		ret = "segnalazioni_trasparenza";
    	}
     
        return ret;
    }

}