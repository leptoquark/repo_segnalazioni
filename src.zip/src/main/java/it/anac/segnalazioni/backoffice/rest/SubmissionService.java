package it.anac.segnalazioni.backoffice.rest;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.file.Files;
import java.nio.file.Paths;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.InputStreamResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping(path="/ws")
public class SubmissionService {
	
	@Autowired
	private ClientReportService clientReportService;
	
	@GetMapping("/pdfFromProtocollo")
	public  ResponseEntity<InputStreamResource> pdfFromProtocollo(String submissionId) throws IOException
	{
		
        String tmpDir = System.getProperty("java.io.tmpdir") + File.separator;
		String filePath = tmpDir+submissionId+"_"+System.currentTimeMillis()+".pdf";
		
		OutputStream os = new FileOutputStream(filePath);
        os.write(clientReportService.download(submissionId));
        os.close();
        
        InputStream inputStream = new FileInputStream(new File(filePath));
	    InputStreamResource inputStreamResource = new InputStreamResource(inputStream);
	    HttpHeaders headers = new HttpHeaders();
	    headers.setContentType(MediaType.APPLICATION_PDF);
	    headers.setContentLength(Files.size(Paths.get(filePath)));
	    
	    return new ResponseEntity(inputStreamResource, headers, HttpStatus.OK);
	}
}
