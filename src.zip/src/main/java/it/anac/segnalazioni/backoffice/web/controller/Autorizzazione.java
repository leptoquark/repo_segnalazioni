package it.anac.segnalazioni.backoffice.web.controller;

import java.security.Principal;

import org.keycloak.KeycloakPrincipal;
import org.keycloak.adapters.springsecurity.token.KeycloakAuthenticationToken;
import org.keycloak.representations.IDToken;
import org.springframework.security.core.context.SecurityContextHolder;

public class Autorizzazione {
	
	protected final String ADMIN = "SEGNALAZIONI_ADMIN";
	protected final String USER =  "SEGNALAZIONI_USER";
	
	protected String autorizza(String role)
	{		
		String username = null;
		
		// Inserire try catch
				
		KeycloakAuthenticationToken authentication = (KeycloakAuthenticationToken) 
	    SecurityContextHolder.getContext().getAuthentication();
	    
	    Principal principal = (Principal) authentication.getPrincipal();      
	    
	    if (principal instanceof KeycloakPrincipal) {
	        KeycloakPrincipal<?> kPrincipal = (KeycloakPrincipal<?>) principal;
	        IDToken token = kPrincipal.getKeycloakSecurityContext().getIdToken();
	        
	        if (token.getOtherClaims().get("gruppo").toString().contains(role))
	        	username = token.getPreferredUsername();
	    }
	    
		return username;
	}
}
