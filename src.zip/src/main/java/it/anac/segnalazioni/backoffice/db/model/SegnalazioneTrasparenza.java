package it.anac.segnalazioni.backoffice.db.model;

/**
 * @author Giancarlo Carbone
 *
 */
import java.util.Date;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonDeserialize;

import it.anac.segnalazioni.backoffice.web.controller.IsoDateDeSerializer;

import java.util.ArrayList;

public class SegnalazioneTrasparenza extends Segnalazione {
	
	
	// Ente segnalato (obbligatorio)
	private Organizzazione ente;
	
	// Link sito web (obbligatorio)
	private String link;
	
	// Contenuto della segnalazione (obbligatorio)
	private String contenuto;
	
	// Carenze indicate dale segnalante (obbligatorio)
	private List<Carenza> carenze;
	
	// Descrizione delle carenze
	private String descrizione;
	
	// Segnalante ha inviato richiesta di accesso civico
	private boolean accessoCivico;
	
	// Segnalante è un RPCT oppure OIV
	private boolean rpctOiv;

	// Allegato istanza di accesso civico
	private String instanzaAccesso;
	
	// Data di invio della istanza di accesso civico
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date dataInvioIstanza;
	
	// Allegato risposta fornita da amministrazione
	private String rispostaAccesso;
	
	// Data di ricezione della risposta alla domanda di accesso civico
	@JsonDeserialize(using = IsoDateDeSerializer.class)
	private Date dataRisposta;
	
	/**
	 * 
	 * @param segnalante Dati del segnalante
	 * @param data		 Data di invio della segnalazione
	 * @param ente		 Ente segnalato
	 * @param link 		 Link del sito web verificato dal segnalante
	 * @param contenuto  Contenuto della segnalazione (Assenza o Carenza)
	 * @param accesso    Il segnalante ha inviato richiesta di accesso civico?
	 */
	
	public SegnalazioneTrasparenza() {};
	
	public SegnalazioneTrasparenza(Segnalante segnalante, Date data, Organizzazione ente, String link, String contenuto,
			boolean rpctOiv) {
		super(segnalante, data, "Trasparenza");
		
		this.ente = ente;
		this.link = link;
		this.contenuto = contenuto;
		this.rpctOiv = rpctOiv;
		this.carenze = new ArrayList<Carenza>();

	}

	public Organizzazione getEnte() {
		return ente;
	}

	public void setEnte(Organizzazione enteSegnalato) {
		this.ente = enteSegnalato;
	}

	public String getLink() {
		return link;
	}

	public void setLink(String link) {
		this.link = link;
	}

	public String getContenuto() {
		return contenuto;
	}

	public void setContenuto(String contenuto) {
		this.contenuto = contenuto;
	}

	public String getDescrizione() {
		return descrizione;
	}

	public void setDescrizione(String descrizione) {
		this.descrizione = descrizione;
	}

	public List<Carenza> getCarenze() {
		return carenze;
	}

	public void setCarenze(List<Carenza> carenze) {
		this.carenze = carenze;
	}
	
	public void addCarenza(Carenza ca) {
		this.carenze.add(ca);
	}

	public boolean isAccessoCivico() {
		return accessoCivico;
	}

	public void setAccessoCivico(boolean accessoCivico) {
		this.accessoCivico = accessoCivico;
	}

	public String getInstanzaAccesso() {
		return instanzaAccesso;
	}

	public void setInstanzaAccesso(String instanzaAccesso) {
		this.instanzaAccesso = instanzaAccesso;
	}

	public String getRispostaAccesso() {
		return rispostaAccesso;
	}

	public void setRispostaAccesso(String rispostaAccesso) {
		this.rispostaAccesso = rispostaAccesso;
	}
	
	public boolean isRpctOiv() {
		return rpctOiv;
	}

	public void setRpctOiv(boolean rpctOiv) {
		this.rpctOiv = rpctOiv;
	}

	public Date getDataInvioIstanza() {
		return dataInvioIstanza;
	}

	public void setDataInvioIstanza(Date dataInvioIstanza) {
		this.dataInvioIstanza = dataInvioIstanza;
	}

	public Date getDataRisposta() {
		return dataRisposta;
	}

	public void setDataRisposta(Date dataRisposta) {
		this.dataRisposta = dataRisposta;
	}

	
}
