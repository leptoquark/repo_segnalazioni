package it.anac.segnalazioni.backoffice.web.model;

import java.util.Date;

public class Assegnazione {
	private int anno;
	private int nrProtocollo;
	private String dataProtocollo;
	private String dataAssegnazione;
	private String ufficioAssegnante;
	private String utenteAssegnante;
	private String ufficioAssegnatario;
	private String utenteAssegnatario;
	private String statoAssegnazione;
	
	public int getAnno() {
		return anno;
	}
	public void setAnno(int anno) {
		this.anno = anno;
	}
	public int getNrProtocollo() {
		return nrProtocollo;
	}
	public void setNrProtocollo(int nrProtocollo) {
		this.nrProtocollo = nrProtocollo;
	}
	public String getDataProtocollo() {
		return dataProtocollo;
	}
	public void setDataProtocollo(String dataProtocollo) {
		this.dataProtocollo = dataProtocollo;
	}
	public String getDataAssegnazione() {
		return dataAssegnazione;
	}
	public void setDataAssegnazione(String dataAssegnazione) {
		this.dataAssegnazione = dataAssegnazione;
	}
	public String getUfficioAssegnante() {
		return ufficioAssegnante;
	}
	public void setUfficioAssegnante(String ufficioAssegnante) {
		this.ufficioAssegnante = ufficioAssegnante;
	}
	public String getUtenteAssegnante() {
		return utenteAssegnante;
	}
	public void setUtenteAssegnante(String utenteAssegnante) {
		this.utenteAssegnante = utenteAssegnante;
	}
	public String getUfficioAssegnatario() {
		return ufficioAssegnatario;
	}
	public void setUfficioAssegnatario(String ufficioAssegnatario) {
		this.ufficioAssegnatario = ufficioAssegnatario;
	}
	public String getUtenteAssegnatario() {
		return utenteAssegnatario;
	}
	public void setUtenteAssegnatario(String utenteAssegnatario) {
		this.utenteAssegnatario = utenteAssegnatario;
	}
	public String getStatoAssegnazione() {
		return statoAssegnazione;
	}
	public void setStatoAssegnazione(String statoAssegnazione) {
		this.statoAssegnazione = statoAssegnazione;
	}
	
}
