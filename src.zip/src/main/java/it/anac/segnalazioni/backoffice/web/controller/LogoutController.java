package it.anac.segnalazioni.backoffice.web.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class LogoutController {
	
	@RequestMapping("/logout")
	public String logout(HttpServletRequest request) throws IOException, ServletException 
	{
		request.logout();
		return "index";
	}
}