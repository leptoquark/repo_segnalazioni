package it.anac.segnalazioni.backoffice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class SegnalazioniBackofficeApplication
{
	public static void main(String[] args) {
		SpringApplication.run(SegnalazioniBackofficeApplication.class, args);
	}
}