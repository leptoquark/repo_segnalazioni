package it.anac.segnalazioni.backoffice.notifiche.model;

public class Messaggio {
	private String oggetto;
	private String messaggio;
	
	public String getOggetto() {
		return oggetto;
	}
	public void setOggetto(String oggetto) {
		this.oggetto = oggetto;
	}
	public String getMessaggio() {
		return messaggio;
	}
	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}
	
	public Messaggio(String oggetto, String messaggio)
	{
		this.oggetto=oggetto;
		this.messaggio=messaggio;
	}
}
