package it.anac.segnalazioni.backoffice.notifiche.model;

public class Tipo
{
	private String tipo;
	
	public final static String SEMESTRALE = "semestrale";
	public final static String GIORNALIERA= "giornaliera";
	
	public String getTipo() {
		return tipo;
	}
	
	public void setTipo(String tipo) 
	{
		this.tipo = tipo;		
	}
}