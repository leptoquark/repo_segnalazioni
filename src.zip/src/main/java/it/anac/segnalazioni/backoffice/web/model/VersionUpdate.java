package it.anac.segnalazioni.backoffice.web.model;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Version")
public class VersionUpdate {
	
	private String versione;
	private String update ;
	
	public String getVersione() {
		return versione;
	}
	public void setVersione(String versione) {
		this.versione = versione;
	}
	public String getUpdate() {
		return update;
	}
	public void setUpdate(String update) {
		this.update = update;
	}
}
