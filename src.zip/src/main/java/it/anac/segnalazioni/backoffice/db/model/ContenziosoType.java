package it.anac.segnalazioni.backoffice.db.model;

/**
 * @author Giancarlo Carbone
 *
 */
public enum ContenziosoType {
	
	CIVILE("Contenzioso Civile"), 
	PENALE("Contenzioso Penale"), 
	ANAC("Altro procedimento/determinazione ANAC"), 
	CORTE_CONTI("Procedimento davanti alla Corte dei conti"), 
	AUTOTUTELA("Procedimento amministrativo in autotutela"), 
	DISCIPLINARE("Procedimento disciplinare"), 
	AMMINISTRATIVO("Contenzioso amministrativo"),
	ALTRO("Altre segnalazioni inviate ad ANAC");
	
	private String tipo;
	
	ContenziosoType(String tipo) {
		this.tipo = tipo;
	}
	
	public String getTipo() {
		return this.tipo;
	}
}