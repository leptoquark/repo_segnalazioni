package it.anac.segnalazioni.backoffice.web.controller;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.jwt.Jwt;
import org.springframework.security.jwt.JwtHelper;
import org.springframework.security.jwt.crypto.sign.MacSigner;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.opencsv.exceptions.CsvValidationException;

import it.anac.segnalazioni.backoffice.web.util.FirmUsers;
import it.anac.segnalazioni.backoffice.web.util.Mapper;

@SuppressWarnings("deprecation")
@Controller
public class Dashboard extends Autorizzazione {
	
	@Value("${dashboard.metabase_site_url}")
    private String METABASE_SITE_URL;
	
	@Value("${dashboard.metabase_secret_key}")
    private String METABASE_SECRET_KEY;

	@Value("${dashboard.metabase_id_root}")
    private int METABASE_ID_ROOT;
	
	@Value("${dashboard.metabase_id_allegati}")
    private int METABASE_ID_ALLEGATI;
	
	@Value("${dashboard.metabase_id_tempo}")
    private int METABASE_ID_TEMPO;
	
	@Value("${backoffice.versione}")
    private String VERSIONE;
	
	public String getDashboard() {
		return getDashboard(METABASE_ID_ROOT);
    }
	
	public String getDashboard(int id) {
        try {
            Jwt token = JwtHelper.encode(dashJson(id), new MacSigner(METABASE_SECRET_KEY));
            String iframeUrl = METABASE_SITE_URL + "/embed/dashboard/" + token.getEncoded() + "#bordered=true&titled=true";
            return iframeUrl;
        } catch (Exception exception) {
            throw exception;
        }
    }

    private static String dashJson(int dashId) {
        String jsonTemplate = "{\"resource\": {\"dashboard\": %d}, \"params\": {}}";
        return String.format(jsonTemplate, dashId);
    }
    
    @GetMapping(path = "/dashboard")
    public String dashboard(Model model) throws CsvValidationException, IOException {
    	
    	String username = autorizza(super.USER);
    	if (username!=null)
    	{
        	model.addAttribute("dashboard_url", getDashboard());
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    	}
    	
    	return "dashboard";
    }
    
    @GetMapping(path = "/allegati")
    public String allegati(Model model) throws CsvValidationException, IOException {  

    	String username = autorizza(super.USER);
    	if (username!=null)
    	{
    		model.addAttribute("dashboard_url", getDashboard(METABASE_ID_ALLEGATI));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    	}
    	
    	
    	return "allegati";
    }
    
    @GetMapping(path = "/tempo")
    public String tempo(Model model) throws CsvValidationException, IOException {
    	
    	String username = autorizza(super.USER);
    	if (username!=null)
    	{
        	model.addAttribute("dashboard_url", getDashboard(METABASE_ID_TEMPO));
    		model.addAttribute("username", username);
    		model.addAttribute("nome",FirmUsers.getNomeCognomeFromUsername(username));
    		model.addAttribute("ruolo", FirmUsers.getRuoloFromUsername(username).toUpperCase());
    		model.addAttribute("ufficio", FirmUsers.getUfficioFromUsername(username).toUpperCase());
    		model.addAttribute("versione","Versione: "+VERSIONE);
    	}
    	    	
    	return "tempo";
    }

}
