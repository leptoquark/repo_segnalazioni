package it.anac.segnalazioni.backoffice.db.model;

public class SegnalazioneRecord {
	
	private String idSottomissione;
	private String ufficioCompetente;
	private String protocollo;
	
	private Segnalazione segnalazione;
	
	private Backoffice backoffice;
	
	public Backoffice getBackoffice() {
		return backoffice;
	}
	public void setBackoffice(Backoffice backoffice) {
		this.backoffice = backoffice;
	}
	public Segnalazione getSegnalazione() {
		return segnalazione;
	}
	public void setSegnalazione(Segnalazione segnalazione) {
		this.segnalazione = segnalazione;
	}
	public String getIdSottomissione() {
		return idSottomissione;
	}
	public void setIdSottomissione(String idSottomissione) {
		this.idSottomissione = idSottomissione;
	}
	public String getProtocollo() {
		return protocollo;
	}
	public void setProtocollo(String protocollo) {
		this.protocollo = protocollo;
	}
	public String getUfficioCompetente() {
		return ufficioCompetente;
	}
	public void setUfficioCompetente(String ufficioCompetente) {
		this.ufficioCompetente = ufficioCompetente;
	}
}
