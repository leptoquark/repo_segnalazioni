package it.anac.segnalazioni.backoffice.db.model;

public class Assegnatario {
	private String utenteAssegnatario;
	private String statoAssegnazione;
	private String dataAssegnazione;
	
	public String getUtenteAssegnatario() {
		return utenteAssegnatario;
	}
	public void setUtenteAssegnatario(String utenteAssegnatario) {
		this.utenteAssegnatario = utenteAssegnatario;
	}
	public String getStatoAssegnazione() {
		return statoAssegnazione.toUpperCase();
	}
	public void setStatoAssegnazione(String statoAssegnazione) {
		this.statoAssegnazione = statoAssegnazione;
	}
	public String getDataAssegnazione() {
		return dataAssegnazione;
	}
	public void setDataAssegnazione(String dataAssegnazione) {
		this.dataAssegnazione = dataAssegnazione;
	}
	
	
}
