package it.anac.segnalazioni.backoffice.db.model;

/**
 * @author Giancarlo Carbone
 *
 */
import java.util.Date;

/*
 * Soggetto inadenpiente in caso di segnalazione da parte di un RPCT
 */
public class SoggettoInadempiente extends Persona {
	
	// Anni duranta del mandato (obbligatorio)
	private String mandato;
	
	// Cessato dal servizio (obbligatorio)
	private boolean cessato;
	
	// Data cessazione (obbligatorio)
	private Date dataCessato;
	
	// Indirizzo PEC personale (obbligatorio)
	private String pec;
	
	// Via/Piazza (obbligatorio)
	private String indirizzo;
	
	// Numero civico (obbligatorio)
	private String civico;
	
	// Nazione (obbligatorio)
	private String nazione;
	
	// Provincia (obbligatorio)
	private String provincia;
	
	// Comune (obbligatorio)
	private String comune;
	
	// Dichiarazione patrimoniale (obbligatorio)
	private boolean patrimoniale;
	
	// Annualità di pertinenza dichiarazione patrimoniale
	private String anniPatrimoniale;
	
	// Dichiarazione reddituale (obbligatorio)
	private boolean reddituale;
	
	// Anni pertinenza dichiarazione reddituale
	private String anniReddituale;
	
	public SoggettoInadempiente() {};

	public SoggettoInadempiente(String nome, String cognome, String cf, String mandato, String qualifica, 
			Date dataCessato, String pec, String indirizzo, String civico, String nazione, String provincia, String comune,
			String anniPatrimoniale, String anniReddituale) {
		
		super(nome, cognome, cf);
		this.setQualifica(qualifica);
		this.mandato = mandato;
		this.dataCessato = dataCessato;
		this.cessato = (dataCessato!=null);
		this.pec = pec;
		this.indirizzo = indirizzo;
		this.civico = civico;
		this.nazione = nazione;
		this.provincia = provincia;
		this.comune = comune;
		this.patrimoniale =  (anniPatrimoniale!= null);
		this.anniPatrimoniale = anniPatrimoniale;
		this.reddituale = (anniReddituale!= null);
		this.anniReddituale = anniReddituale;

	}

	public String getMandato() {
		return mandato;
	}

	public void setMandato(String mandato) {
		this.mandato = mandato;
	}

	public boolean isCessato() {
		return cessato;
	}

	public String getPec() {
		return pec;
	}

	public void setPec(String pec) {
		this.pec = pec;
	}

	public String getIndirizzo() {
		return indirizzo;
	}

	public void setIndirizzo(String indirizzo) {
		this.indirizzo = indirizzo;
	}

	public String getCivico() {
		return civico;
	}

	public void setCivico(String civico) {
		this.civico = civico;
	}

	public String getNazione() {
		return nazione;
	}

	public void setNazione(String nazione) {
		this.nazione = nazione;
	}

	public String getProvincia() {
		return provincia;
	}

	public void setProvincia(String provincia) {
		this.provincia = provincia;
	}

	public String getComune() {
		return comune;
	}

	public void setComune(String comune) {
		this.comune = comune;
	}

	public boolean isPatrimoniale() {
		return patrimoniale;
	}

	public String getAnniPatrimoniale() {
		return anniPatrimoniale;
	}

	public void setAnniPatrimoniale(String anniPatrimoniale) {
		this.anniPatrimoniale = anniPatrimoniale;
	}

	public boolean isReddituale() {
		return reddituale;
	}

	public String getAnniReddituale() {
		return anniReddituale;
	}

	public void setAnniReddituale(String anniReddituale) {
		this.anniReddituale = anniReddituale;
	}

	public Date getDataCessato() {
		return dataCessato;
	}

	public void setDataCessato(Date dataCessato) {
		this.dataCessato = dataCessato;
	}

}
