package it.anac.segnalazioni.backoffice.db.model;

/**
 * @author Giancarlo Carbone
 *
 */
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 
 */
public class SoggettoInteressato {
	
	// Nome del soggetto (obbligatorio)
	private String nome;
	
	// Cognome del soggetto (obbligatorio)
	private String cognome;
	
	// Incarico in provenienza (obbligatorio)
	private Incarico incarico;
	
	// Incarichi in destinazione
	private List<Incarico> listaIncarichi;
	
	public SoggettoInteressato() {};
	
	public SoggettoInteressato(String nome, String cognome, Incarico incarico) {
		this.nome = nome;
		this.cognome = cognome;
		this.incarico = incarico;
		this.listaIncarichi = new ArrayList<Incarico>();
	}
	public SoggettoInteressato(String nome, String cognome, String denominazione, boolean inCorso) {
		this.nome = nome;
		this.cognome = cognome;
		this.incarico = new Incarico(denominazione, inCorso);
		this.listaIncarichi = new ArrayList<Incarico>();
	}
	
	public SoggettoInteressato(String nome, String cognome, String denominazione, Date dataAssunzione, boolean inCorso) {
		this.nome = nome;
		this.cognome = cognome;
		this.incarico = new Incarico(denominazione, dataAssunzione, inCorso);
		this.listaIncarichi = new ArrayList<Incarico>();
	}
	
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCognome() {
		return cognome;
	}
	public void setCognome(String cognome) {
		this.cognome = cognome;
	}

	public Incarico getIncarico() {
		return incarico;
	}
	public void setIncarico(Incarico incarico) {
		this.incarico = incarico;
	}
	
	public void addIncarico(Incarico incarico)	{
		this.listaIncarichi.add(incarico);
	}

	public List<Incarico> getListaIncarichi() {
		return listaIncarichi;
	}

}
