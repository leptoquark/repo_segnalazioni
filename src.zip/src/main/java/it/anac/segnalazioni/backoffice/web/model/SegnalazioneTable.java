package it.anac.segnalazioni.backoffice.web.model;

import java.util.List;

import it.anac.segnalazioni.backoffice.db.model.Ufficio;

public class SegnalazioneTable {
	
	private String protocollo;
	private String ufficioCompetente;
	private String segnalante;
	private String nome_segnalante;
	private String cognome_segnalante;
	private String cf_segnalante;
	private String qualifica;
	private String ente_segnalante;
	private String data;
	private int gg;
	private String area;
	private String stato;
	private String ente_segnalato;
	private String protocolloChiusura;
	private String dataChiusura;

	private boolean soglia = false;
	
	public String getDataChiusura() {
		return dataChiusura;
	}
	public void setDataChiusura(String dataChiusura) {
		this.dataChiusura = dataChiusura;
	}
	
	public boolean isSoglia() {
		return soglia;
	}
	public void setSoglia(boolean soglia) {
		this.soglia = soglia;
	}
	private List<Ufficio> uffici;	
	
	public List<Ufficio> getUffici() {
		return uffici;
	}
	public void setUffici(List<Ufficio> uffici) {
		this.uffici = uffici;
	}
	public String getNome_segnalante() {
		return nome_segnalante;
	}
	public void setNome_segnalante(String nome_segnalante) {
		this.nome_segnalante = nome_segnalante;
	}
	public String getCognome_segnalante() {
		return cognome_segnalante;
	}
	public void setCognome_segnalante(String cognome_segnalante) {
		this.cognome_segnalante = cognome_segnalante;
	}
	public String getCf_segnalante() {
		return cf_segnalante;
	}
	public void setCf_segnalante(String cf_segnalante) {
		this.cf_segnalante = cf_segnalante;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getProtocolloChiusura() {
		return protocolloChiusura;
	}
	public void setProtocolloChiusura(String protocolloChiusura) {
		this.protocolloChiusura = protocolloChiusura;
	}
	private String idSottomissione;
	
	public String getUfficioCompetente() {
		return ufficioCompetente;
	}
	public void setUfficioCompetente(String ufficioCompetente) {
		this.ufficioCompetente = ufficioCompetente;
	}
	public String getIdSottomissione() {
		return idSottomissione;
	}
	public void setIdSottomissione(String idSottomissione) {
		this.idSottomissione = idSottomissione;
	}
	private String oggetto_segnalazione;
	
	public String getProtocollo() {
		return protocollo;
	}
	public void setProtocollo(String protocollo) {
		this.protocollo = protocollo;
	}
	public String getSegnalante() {
		return segnalante;
	}
	public void setSegnalante(String segnalante) {
		this.segnalante = segnalante;
	}
	public String getQualifica() {
		return qualifica;
	}
	public void setQualifica(String qualifica) {
		this.qualifica = qualifica;
	}
	public String getEnte_segnalante() {
		return ente_segnalante;
	}
	public void setEnte_segnalante(String ente_segnalante) {
		this.ente_segnalante = ente_segnalante;
	}
	public String getData() {
		return data;
	}
	public void setData(String data) {
		this.data = data;
	}
	public int getGg() {
		return gg;
	}
	public void setGg(int gg) {
		this.gg = gg;
	}
	public String getStato() {
		return stato;
	}
	public void setStato(String stato) {
		this.stato = stato;
	}
	public String getEnte_segnalato() {
		return ente_segnalato;
	}
	public void setEnte_segnalato(String ente_segnalato) {
		this.ente_segnalato = ente_segnalato;
	}
	public String getOggetto_segnalazione() {
		return oggetto_segnalazione;
	}
	public void setOggetto_segnalazione(String oggetto_segnalazione) {
		this.oggetto_segnalazione = oggetto_segnalazione;
	}

}