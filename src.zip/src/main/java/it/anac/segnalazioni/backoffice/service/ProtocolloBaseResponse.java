package it.anac.segnalazioni.backoffice.service;

public class ProtocolloBaseResponse {
	private String esito;
	private String messaggio;
	
	public String getEsito() {
		return esito;
	}
	public void setEsito(String esito) {
		this.esito = esito;
	}
	public String getMessaggio() {
		return messaggio;
	}
	public void setMessaggio(String messaggio) {
		this.messaggio = messaggio;
	}
}