package it.anac.segnalazioni.backoffice.rest;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import org.springframework.web.reactive.function.client.WebClientException;

import reactor.core.publisher.Mono;

@Service
public class ClientReportService
{
	@Value("${segnalazioni.report.service.uri}")
	private String reportServiceUri;
	
	private WebClient webClient;

	public ClientReportService(WebClient.Builder webClientBuilder) {
		this.webClient = webClientBuilder.baseUrl(reportServiceUri).build();
	}
	
	public byte[] download(String submissionId)
	{
		byte[] report = null;
		Mono<byte[]> response = webClient
		.get()
		.uri(reportServiceUri + "/report?id={submissionId}", submissionId)
		.retrieve()
		.bodyToMono(byte[].class); // non bloccante
		try {
			report = response.block(); // bloccante
		} catch (WebClientException e) {
			e.printStackTrace();
		}
		return report;
	}
}